package com.weechong_teo.wdf.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.context.WebApplicationContext;

import com.weechong_teo.wdf.config.JpaConfig;
import com.weechong_teo.wdf.config.SecurityConfig;
import com.weechong_teo.wdf.config.WebMvcConfig;
import com.weechong_teo.wdf.entity.User;
import com.weechong_teo.wdf.entity.UserProfile;
import com.weechong_teo.wdf.exception.DuplicateEmailException;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes={WebMvcConfig.class, JpaConfig.class, SecurityConfig.class})
@WebAppConfiguration
class UserServiceTest {

	@Autowired
	UserService userService;
	
	@Autowired
	private WebApplicationContext context;
		
	@Test
	void testSaveProfile() {
		UserProfile userProfile = new UserProfile();
		userProfile.setUserProfileId((long) 130);
		userProfile.setFirstName("First");
		userProfile.setLastName("Last");
		userProfile.setDateOfBirth("1999-09-09");
		userProfile.setGender("Female");
		userProfile.setCity("Tokyo");
		userProfile.setCountry("Japan");
		assertNotNull(userService.saveUserProfile(userProfile));
	}
}
