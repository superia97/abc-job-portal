package com.weechong_teo.wdf.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.context.WebApplicationContext;

import com.weechong_teo.wdf.config.JpaConfig;
import com.weechong_teo.wdf.config.SecurityConfig;
import com.weechong_teo.wdf.config.WebMvcConfig;
import com.weechong_teo.wdf.entity.User;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes={WebMvcConfig.class, JpaConfig.class, SecurityConfig.class})
@WebAppConfiguration
class LoginServiceTest {

	@Autowired
	LoginService loginService;
	
	@Autowired
	private WebApplicationContext context;
	
	@Test
	void testValidUserName() {
		User loginUser = loginService.findByUserName("john@gmail.com");
		assertTrue(loginUser instanceof User);
	}

	@Test
	void testInvalidUserName() {
		User loginUser = loginService.findByUserName("notFound@gmail.com");
		assertNull(loginUser);
	}
	
	@Test
	void testInvalidUser() {
		User testUser = new User();
		testUser.setUserName("john@gmail.com");
		testUser.setPassword("2");
		Optional<User> loginUser = loginService.isValidUser(testUser);
		assertFalse(loginUser.isPresent());
	}
	
	@Test
	void testValidUser() {
		User testUser = new User();
		testUser.setUserName("john@gmail.com");
		testUser.setPassword("1");
		Optional<User> loginUser = loginService.isValidUser(testUser);
		assertTrue(loginUser.isPresent());
	}
	
}
