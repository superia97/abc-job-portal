package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CalculatorTest {

	private Calculator myCal = new Calculator();
	
	@Test
	void testAdd() {
		// Actual = expected = > pass
		// other failed
		assertEquals(2, myCal.add()); 
		
	}

	@Test
	void testSubstract() {
		assertEquals(0, myCal.substract());
	}

	@Test
	void testMultiply() {
		assertEquals(1, myCal.multiply());
	}

}
