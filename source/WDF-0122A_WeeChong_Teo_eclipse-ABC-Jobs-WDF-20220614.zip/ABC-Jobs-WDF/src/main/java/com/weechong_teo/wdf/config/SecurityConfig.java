/**
 * 
 */
package com.weechong_teo.wdf.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.session.HttpSessionEventPublisher;

import com.weechong_teo.wdf.auth.UserDetailsServiceImpl;

/**
 * @author WeeChong
 *
 */
@Configuration
@EnableWebSecurity
@ComponentScan("com.weechong_teo") 
public class SecurityConfig extends WebSecurityConfigurerAdapter {
	
    @Bean
    @Override
    public UserDetailsService userDetailsService() {
        return new UserDetailsServiceImpl();
    }

//    @Autowired
//    private PasswordEncoder passwordEncoder;
	
//	@Bean
//    @Override
//	protected UserDetailsService userDetailsService() {
//		UserDetails testUser = User.builder()
//				.username("john@gmail.com")
//				.password(passwordEncoder.encode("1"))
//				.roles("Member")
//				.build();
//		
//		return new InMemoryUserDetailsManager(testUser);
//	}


	@Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    
//    @SuppressWarnings("deprecation")
//    @Bean
//    public static NoOpPasswordEncoder noPasswordEncoder() {
//    return (NoOpPasswordEncoder) NoOpPasswordEncoder.getInstance();
//    }
//    
    @Bean
    public HttpSessionEventPublisher httpSessionEventPublisher() {
        return new HttpSessionEventPublisher();
    }
    
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
    	System.out.println("At Authen configure");
    	
        auth.userDetailsService(userDetailsService()).passwordEncoder(passwordEncoder());
        
        
//        UserDetails principal = userDetailsService.loadUserByUsername(username);
//        Authentication authentication = new UsernamePasswordAuthenticationToken(principal, principal.getPassword(), principal.getAuthorities());
//        SecurityContext context = SecurityContextHolder.createEmptyContext();
//        context.setAuthentication(authentication);
    }
    
    @Override
    protected void configure(HttpSecurity http) throws Exception {
 
    	System.out.println("At Security configure");
    	
        http.sessionManagement()
    		.sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED)
        	.maximumSessions(1)
        	.expiredUrl("/login?invalid-session=true");
        
        
        http
        	.authorizeRequests()  
	        .antMatchers("/", "/home", "/showRegister", "/register", "/resetPassword").permitAll()
	        .antMatchers(HttpMethod.GET, "/login").permitAll()
	        .antMatchers(HttpMethod.POST, "/login").permitAll()
	        .antMatchers(HttpMethod.GET, "/mainPage").permitAll()
	        .antMatchers(HttpMethod.GET, "/showPublicProfile").permitAll()
	        .antMatchers(HttpMethod.GET, "/showProfile").permitAll()
	        .antMatchers(HttpMethod.GET, "/updateUserInfo").permitAll()
	        .antMatchers(HttpMethod.POST, "/saveProfile").permitAll()
	        .antMatchers(HttpMethod.GET, "/addEducation").permitAll()
	        .antMatchers(HttpMethod.POST, "/insertEducation").permitAll()
	        .antMatchers(HttpMethod.GET, "/addExperience").permitAll()
	        .antMatchers(HttpMethod.POST, "/insertExperience").permitAll()
	        .antMatchers(HttpMethod.GET, "/addSkill").permitAll()
	        .antMatchers(HttpMethod.POST, "/insertSkill").permitAll()
	        .antMatchers(HttpMethod.GET, "/search").permitAll()
	        .antMatchers(HttpMethod.POST, "/search").permitAll()
	        .antMatchers(HttpMethod.GET, "/showUsers").permitAll()
//	        .antMatchers(HttpMethod.GET, "/showUsers").hasRole("Administrator")
	        .antMatchers("/css/**").permitAll()
	        .antMatchers("/images/**").permitAll()
	        .antMatchers("/js/**").permitAll()
	        .anyRequest().authenticated()
	        .and()
        	.formLogin().loginPage("/showLogin").loginProcessingUrl("login").permitAll().defaultSuccessUrl("/mainPage")
        	.and()
        	.csrf()
        	.and()
        	.logout().logoutSuccessUrl("/login").invalidateHttpSession(true);
        
//        http.authorizeRequests()  
//        .antMatchers("/home").permitAll()  
//        .antMatchers(HttpMethod.GET, "/mainPage").hasAnyRole("Administrator","Member")
//        .antMatchers(HttpMethod.GET, "/search").permitAll()  
//        .antMatchers(HttpMethod.POST, "/search").permitAll()  
//        .and()  
//        .formLogin().loginPage("/showLogin").loginProcessingUrl("login").permitAll().defaultSuccessUrl("/mainPage") 
//        .and()  
//        .logout().logoutSuccessUrl("/login"); 
      
        
        
//        http
//            .formLogin()
//                .loginPage("/showLogin")
//                .loginProcessingUrl("/login")
//                .failureUrl("/login-error")
//                .permitAll()
//                .defaultSuccessUrl("/mainPage", true)
//            .and()
//            .csrf()
//            .and()
//            .authorizeRequests()
//                .antMatchers("/").permitAll()
//                .antMatchers("/css/**").permitAll()
//                .antMatchers("/images/**").permitAll()
//                .antMatchers("/js/**").permitAll()
//                .antMatchers(HttpMethod.GET, "/favicon.*").permitAll()
//                .antMatchers(HttpMethod.GET, "/mainPage").hasAnyRole("Administrator","Member")
//                .antMatchers(HttpMethod.GET, "/showRegister").permitAll()
//                .antMatchers(HttpMethod.POST, "/register").permitAll()
//                .antMatchers(HttpMethod.GET, "/showLogin").permitAll()
//                .antMatchers(HttpMethod.POST, "/login").permitAll()
//                .antMatchers(HttpMethod.GET, "/login-error").permitAll()
//                .antMatchers(HttpMethod.GET, "/resetPassword").permitAll()
//                .antMatchers(HttpMethod.POST, "/resetPassword").permitAll()
//                .antMatchers(HttpMethod.GET, "/search").hasRole("Member")
//                .antMatchers(HttpMethod.POST, "/search").hasRole("Member")
//                .antMatchers(HttpMethod.GET, "/showPublicProfile").hasRole("Member")
//                .antMatchers(HttpMethod.GET, "/showProfile").hasRole("Member")
//                .antMatchers(HttpMethod.GET, "/updateUserInfo").hasRole("Member")
//                .antMatchers(HttpMethod.POST, "/saveProfile").hasRole("Member")
//                .antMatchers(HttpMethod.GET, "/addEducation").hasRole("Member")
//                .antMatchers(HttpMethod.POST, "/insertEducation").hasRole("Member")
//                .antMatchers(HttpMethod.GET, "/addExperience").hasRole("Member")
//                .antMatchers(HttpMethod.POST, "/insertExperience").hasRole("Member")
//                .antMatchers(HttpMethod.GET, "/addSkill").hasRole("Member")
//                .antMatchers(HttpMethod.POST, "/insertSkill").hasRole("Member")
//                .antMatchers(HttpMethod.GET,"/showUsers").hasRole("Administrator")
//            .and()
//            .logout()
//                .logoutSuccessUrl("/login")
//                .invalidateHttpSession(true);
 //               .deleteCookies("PortalSession");
    }
}
