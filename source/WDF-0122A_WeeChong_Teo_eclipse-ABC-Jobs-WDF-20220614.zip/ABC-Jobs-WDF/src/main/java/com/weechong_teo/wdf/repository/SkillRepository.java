/**
 * 
 */
package com.weechong_teo.wdf.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.weechong_teo.wdf.entity.Skill;

/**
 * @author WeeChong
 *
 */
public interface SkillRepository extends JpaRepository<Skill, Long> {

}
