/**
 * WDF-0122A_WeeChong_Teo
 */
package com.weechong_teo.wdf.entity;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * @author WeeChong
 *
 */
@Entity // Map to DB Table Job
public class Job {
	// Field jobId is annotated with @Id and @GeneratedValue annotations to indicate that 
	// this field is primary key and its value is auto generated.
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long jobId;
	private String jobReferenceNo;
	private String position;
	private String company;
	private String location;
	private String type;
	private String description;
	private String salary;
	private Timestamp closingDate;
	private Long userId;
	
	public Job() {
		super();
	}

	public Job(String jobReferenceNo, String position, String company, String location, String type, String description,
			String salary, Timestamp closingDate, Long userId) {
		super();
		this.jobReferenceNo = jobReferenceNo;
		this.position = position;
		this.company = company;
		this.location = location;
		this.type = type;
		this.description = description;
		this.salary = salary;
		this.closingDate = closingDate;
		this.userId = userId;
	}

	public Long getJobId() {
		return jobId;
	}

	public void setJobId(Long jobId) {
		this.jobId = jobId;
	}

	public String getJobReferenceNo() {
		return jobReferenceNo;
	}

	public void setJobReferenceNo(String jobReferenceNo) {
		this.jobReferenceNo = jobReferenceNo;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSalary() {
		return salary;
	}

	public void setSalary(String salary) {
		this.salary = salary;
	}

	public Timestamp getClosingDate() {
		return closingDate;
	}

	public void setClosingDate(Timestamp closingDate) {
		this.closingDate = closingDate;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}
}
