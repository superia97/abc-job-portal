/**
 * 
 */
package com.weechong_teo.wdf.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.weechong_teo.wdf.entity.User;
import com.weechong_teo.wdf.entity.UserProfile;
import com.weechong_teo.wdf.exception.DuplicateEmailException;
import com.weechong_teo.wdf.service.UserService;

/**
 * @author WeeChong
 *
 */
@Controller
public class RegistrationController {
	
	@Autowired
	UserService userService;

	@RequestMapping(value = "/showRegister", method = RequestMethod.GET)
	public ModelAndView showRegister() {
		ModelAndView mav = new ModelAndView("register");
		mav.addObject("user", new User());
		return mav;
	}
	
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ModelAndView register(@ModelAttribute UserProfile user) {
		try {
			userService.register(user);
			return new ModelAndView("registerConfirmation");
		} catch (DuplicateEmailException e) {
			e.printStackTrace();
			ModelAndView mav = new ModelAndView("register");
			mav.addObject("errorMsg", e.getMessage());
			return mav; 
		}
	}
}
