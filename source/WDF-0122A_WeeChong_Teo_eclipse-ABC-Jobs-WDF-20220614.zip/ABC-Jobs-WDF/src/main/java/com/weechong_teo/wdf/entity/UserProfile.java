/**
 * WDF-0122A_WeeChong_Teo
 */
package com.weechong_teo.wdf.entity;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * @author WeeChong
 *
 */
@Entity // Map to DB Table UserProfile
@Table (name = "UserProfile")
public class UserProfile {
	// Field userProfileId is annotated with @Id and @GeneratedValue annotations to indicate that 
	// this field is primary key and its value is auto generated.
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="userProfileId")
	private Long userProfileId;
	
	@Column(name="firstName")
	private String firstName;
	
	@Column(name="lastName")
	private String lastName;
	
	@Column(name="gender")
	private String gender;
	
	@Column(name="dateOfBirth")
	private String dateOfBirth;
	
	@Column(name="city")
	private String city;
	
	@Column(name="country")
	private String country;
	
	@Column(name="photo")
	private String photo = "user.jpg";
	
	@Column(name="email")
	private String email;
	
	@Transient 
	private String password; 

	@Transient 
	private String confirmPassword; 
	
	@ManyToOne	
    @JoinColumn(name = "roleId")
	private Role role;	
	
	@OneToOne( mappedBy = "userProfile")
	private User user;
	
	@OneToMany (mappedBy="skillUserProfile", cascade=CascadeType.ALL, fetch=FetchType.EAGER)
	private List<Skill> skills = new ArrayList<>();
	
//	@OneToMany (mappedBy="experienceUserProfile", cascade=CascadeType.ALL, fetch=FetchType.EAGER)
	@Transient
	private List<Experience> experiences = new ArrayList<>();
	
	public UserProfile() {
		super();
	}

	public Long getUserProfileId() {
		return userProfileId;
	}

	public void setUserProfileId(Long userProfileId) {
		this.userProfileId = userProfileId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public List<Skill> getSkills() {
		return skills;
	}

	public void setSkills(List<Skill> skills) {
		this.skills = skills;
	}

	public List<Experience> getExperiences() {
		return experiences;
	}

	public void setExperiences(List<Experience> experiences) {
		this.experiences = experiences;
	}




	
	
	
}
