/**
 * WDF-0122A_WeeChong_Teo
 */
package com.weechong_teo.wdf.entity;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * @author WeeChong
 *
 */
@Entity // Map to DB Table Thread
public class Thread {
	// Field threadId is annotated with @Id and @GeneratedValue annotations to indicate that 
	// this field is primary key and its value is auto generated.
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long threadId;
	private Timestamp dateTime;
	private String content;
	private String media;
	private char status; 
	private Long userId;
	private Long replyToThreadId;
	
	public Thread() {
		super();
	}

	public Thread(Timestamp dateTime, String content, String media, char status, Long userId, Long replyToThreadId) {
		super();
		this.dateTime = dateTime;
		this.content = content;
		this.media = media;
		this.status = status;
		this.userId = userId;
		this.replyToThreadId = replyToThreadId;
	}

	public Long getThreadId() {
		return threadId;
	}

	public void setThreadId(Long threadId) {
		this.threadId = threadId;
	}

	public Timestamp getDateTime() {
		return dateTime;
	}

	public void setDateTime(Timestamp dateTime) {
		this.dateTime = dateTime;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getMedia() {
		return media;
	}

	public void setMedia(String media) {
		this.media = media;
	}

	public char getStatus() {
		return status;
	}

	public void setStatus(char status) {
		this.status = status;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getReplyToThreadId() {
		return replyToThreadId;
	}

	public void setReplyToThreadId(Long replyToThreadId) {
		this.replyToThreadId = replyToThreadId;
	}
}
