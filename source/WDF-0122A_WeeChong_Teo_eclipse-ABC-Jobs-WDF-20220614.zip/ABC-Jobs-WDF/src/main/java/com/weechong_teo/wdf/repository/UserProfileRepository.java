/**
 * 
 */
package com.weechong_teo.wdf.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.weechong_teo.wdf.entity.UserProfile;

/**
 * @author WeeChong
 *
 */
public interface UserProfileRepository extends JpaRepository<UserProfile, Long> {

	UserProfile findByEmail(String email);

	@Query("SELECT m FROM UserProfile m WHERE m.firstName LIKE ?1% OR m.lastName LIKE ?1% OR m.city LIKE ?1% OR m.country LIKE ?1%")
    List<UserProfile> search(String searchText);
}
