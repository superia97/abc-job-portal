/**
 * 
 */
package com.weechong_teo.wdf.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.weechong_teo.wdf.entity.User;
import com.weechong_teo.wdf.exception.DuplicateEmailException;
import com.weechong_teo.wdf.exception.EmailNotFoundException;
import com.weechong_teo.wdf.service.UserService;

/**
 * @author WeeChong
 *
 */
@Controller
public class ResetPasswordController {

	@Autowired
	UserService userService;
	
	@RequestMapping(value = "/resetPassword", method = RequestMethod.GET)
	public ModelAndView resetPassword() {
		ModelAndView mav = new ModelAndView("resetPassword");
		return mav;
	}
	
	@RequestMapping(value = "/resetPassword", method = RequestMethod.POST)
	public ModelAndView onResetPassword(@ModelAttribute User inputUser) {
		ModelAndView mav = null;

		try {
			userService.resetPassword(inputUser);
			return new ModelAndView("resetPasswordConfirmation");
		} catch (EmailNotFoundException e) {
			e.printStackTrace();
			mav = new ModelAndView("resetPassword");
			mav.addObject("errorMsg", e.getMessage());
			return mav; 
		}
	}
}
