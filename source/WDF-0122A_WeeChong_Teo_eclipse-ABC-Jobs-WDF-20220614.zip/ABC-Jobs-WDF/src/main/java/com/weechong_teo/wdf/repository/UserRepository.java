/**
 * 
 */
package com.weechong_teo.wdf.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.weechong_teo.wdf.entity.User;

/**
 * @author WeeChong
 *
 */
public interface UserRepository extends JpaRepository<User, Long> {
	User findByUserName (String userName);

	Optional<User> findByUserNameAndPassword(String userName, String password);
}
