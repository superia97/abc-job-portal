/**
 * WDF-0122A_WeeChong_Teo
 */
package com.weechong_teo.wdf.entity;


/**
 * @author WeeChong
 *
 */
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;


import org.hibernate.annotations.CreationTimestamp;
import org.springframework.data.annotation.Transient;

@Entity // Map to DB Table User
@Table (name = "User")
public class User {
	// Field userId is annotated with @Id and @GeneratedValue annotations to indicate that 
	// this field is primary key and its value is auto generated.
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="userId")
	private Long userId;

	
	@Column(name="userName")
	private String userName;
	
	@Column(name="password")
	private String password;
	
	@Column(name="emailConfirmed")
	private char emailConfirmed = '0';
	
	@Column(name="status")
	private char status = '0';
	
	@Column(name="createdDate")
	@CreationTimestamp
	private Timestamp createdDate;
	
	@Column(name="reset")
	private String reset;
	
	@OneToOne
	@JoinColumn( name = "userProfileId" )
	private UserProfile userProfile;
	   	
	@ManyToMany
	@JoinTable( name="User_Role",
		joinColumns = @JoinColumn(name = "userId"),
		inverseJoinColumns = @JoinColumn(name = "roleId")
	)
	private List<Role> roles = new ArrayList<Role>();
	

	
//	@OneToOne(mappedBy="user",  cascade=CascadeType.ALL)	
//	private UserProfile userProfile;
	
	
	// =====
//	@OneToMany
//	private List<ResetPassword> resetPasswords = new ArrayList<>();
	
//    @OneToMany
//    @JoinTable( name="UserRole",
//                joinColumns = @JoinColumn(name = "userId"),
//                inverseJoinColumns = @JoinColumn(name = "roleId"))
//    private Set<Role> roles = new HashSet<>();
	
//	@Transient 
//	private String confirmPassword; 
	
//	@OneToMany (cascade=CascadeType.ALL)
//	@JoinColumn(name = "userId")
//	private List<Role> roles = new ArrayList<>();
	
	public User() {
		super();
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}



	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public char getEmailConfirmed() {
		return emailConfirmed;
	}

	public void setEmailConfirmed(char emailConfirmed) {
		this.emailConfirmed = emailConfirmed;
	}

	public char getStatus() {
		return status;
	}

	public void setStatus(char status) {
		this.status = status;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public List<Role> getRoles() {
		return roles;
	}

	public void setRoles(List<Role> roles) {
		this.roles = roles;
	}

	public UserProfile getUserProfile() {
		return userProfile;
	}

	public void setUserProfile(UserProfile userProfile) {
		this.userProfile = userProfile;
	}

	public String getReset() {
		return reset;
	}

	public void setReset(String reset) {
		this.reset = reset;
	}


	
}

