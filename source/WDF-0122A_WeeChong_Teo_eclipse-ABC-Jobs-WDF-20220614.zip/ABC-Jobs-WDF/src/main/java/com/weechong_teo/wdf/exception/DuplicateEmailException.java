/**
 * 
 */
package com.weechong_teo.wdf.exception;

/**
 * @author WeeChong
 *
 */
public class DuplicateEmailException extends Exception {

	/**
	 * @param message
	 */
	public DuplicateEmailException(String message) {
		super(message);
	}
}
