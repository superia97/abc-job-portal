/**
 * 
 */
package com.weechong_teo.wdf.exception;

/**
 * @author WeeChong
 *
 */
public class EmailNotFoundException extends Exception {

	/**
	 * @param message
	 */
	public EmailNotFoundException(String message) {
		super(message);
	}

}
