/**
 * WDF-0122A_WeeChong_Teo
 */
package com.weechong_teo.wdf.entity;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * @author WeeChong
 *
 */
@Entity // Map to DB Table Message
public class Message {
	// Field messageId is annotated with @Id and @GeneratedValue annotations to indicate that 
	// this field is primary key and its value is auto generated.
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long messageId;
	private Timestamp dateTime;
	private String content;
	private char status; 
	private Long userId;
	private Long receiverUserId;
	private Long replyToMsgId;
	
	public Message() {
		super();
	}

	public Message(Timestamp dateTime, String content, char status, Long userId, Long receiverUserId,
			Long replyToMsgId) {
		super();
		this.dateTime = dateTime;
		this.content = content;
		this.status = status;
		this.userId = userId;
		this.receiverUserId = receiverUserId;
		this.replyToMsgId = replyToMsgId;
	}

	public Long getMessageId() {
		return messageId;
	}

	public void setMessageId(Long messageId) {
		this.messageId = messageId;
	}

	public Timestamp getDateTime() {
		return dateTime;
	}

	public void setDateTime(Timestamp dateTime) {
		this.dateTime = dateTime;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public char getStatus() {
		return status;
	}

	public void setStatus(char status) {
		this.status = status;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getReceiverUserId() {
		return receiverUserId;
	}

	public void setReceiverUserId(Long receiverUserId) {
		this.receiverUserId = receiverUserId;
	}

	public Long getReplyToMsgId() {
		return replyToMsgId;
	}

	public void setReplyToMsgId(Long replyToMsgId) {
		this.replyToMsgId = replyToMsgId;
	}
}
