/**
 * 
 */
package com.weechong_teo.wdf.auth;

import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.weechong_teo.wdf.entity.User;
import com.weechong_teo.wdf.service.LoginService;

/**
 * @author WeeChong
 *
 */
@Transactional
public class UserDetailsServiceImpl implements UserDetailsService {
    @Autowired
    private LoginService loginService;

    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Autowired
    private HttpSession session;

	public UserDetailsServiceImpl() {
	}
	
	@Override
	public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
        User loginUser = loginService.findByUserName(userName);
        if(loginUser == null) {
            throw new UsernameNotFoundException("Login User " + userName + " is not valid. Please re-enter.");
        }
        org.springframework.security.core.userdetails.User.UserBuilder userBuilder = org.springframework.security.core.userdetails.User.builder();
        
        String role = loginUser.getUserProfile().getRole().getName();
 
        System.out.println("Role Name is "+ role);
		
        return userBuilder.username(loginUser.getUserName())
                        .password(loginUser.getPassword())
                        .roles(role)
                        .passwordEncoder(passwordEncoder::encode)
                        .build();
	}


	

}
