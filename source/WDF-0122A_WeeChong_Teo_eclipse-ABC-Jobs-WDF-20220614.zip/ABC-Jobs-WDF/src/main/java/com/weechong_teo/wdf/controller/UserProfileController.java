/**
 * 
 */
package com.weechong_teo.wdf.controller;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.weechong_teo.wdf.entity.Education;
import com.weechong_teo.wdf.entity.Experience;
import com.weechong_teo.wdf.entity.Skill;
import com.weechong_teo.wdf.entity.User;
import com.weechong_teo.wdf.entity.UserProfile;
import com.weechong_teo.wdf.service.UserService;

/**
 * @author WeeChong
 *
 */
@Controller
public class UserProfileController {
	
	@Autowired
	UserService userService;
	
	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public ModelAndView search() {
		ModelAndView mav = new ModelAndView("search");
		return mav;
	}
	
	@RequestMapping(value = "/search",  method = RequestMethod.POST)
	public ModelAndView onSearch(@RequestParam("searchText") String searchText) {
		List<UserProfile> userList = userService.search(searchText);
		ModelAndView mav = new ModelAndView("search");
		mav.addObject("searchText", searchText);
		mav.addObject("userList", userList);
		return mav;
	}
	
	@RequestMapping(value = "/showPublicProfile",  method = RequestMethod.GET) // Show profile page
	public ModelAndView showPublicProfile(@RequestParam("id") long id) {
		ModelAndView mav = new ModelAndView("showPublicProfile");
		Optional<User> user = userService.findById(id);
		UserProfile userProfile = user.get().getUserProfile();
		List<Education> educations = userService.findAllEducation(userProfile.getUserProfileId());
		List<Experience> experiences = userService.findAllExperience(userProfile.getUserProfileId());
		List<Skill> skills = userProfile.getSkills();
		mav.addObject("userProfile", userProfile);
		mav.addObject("educations", educations);
		mav.addObject("skills", skills);
		mav.addObject("experiences", experiences);
		return mav;
	}

	@RequestMapping(value = "/showProfile",  method = RequestMethod.GET) // Show profile page
	public ModelAndView showProfile(HttpSession session) {
		ModelAndView mav = new ModelAndView("showProfile");
		Optional<User> user = userService.findById((Long) session.getAttribute("login_id"));
		UserProfile userProfile = user.get().getUserProfile();
		List<Education> educations = userService.findAllEducation(userProfile.getUserProfileId());
		List<Experience> experiences = userService.findAllExperience(userProfile.getUserProfileId());
		List<Skill> skills = userProfile.getSkills();
		mav.addObject("userProfile", userProfile);
		mav.addObject("educations", educations);
		mav.addObject("skills", skills);
		mav.addObject("experiences", experiences);
		return mav;
	}
	
	@RequestMapping(value = "/saveProfile", method = RequestMethod.POST)
	public String saveProfile(@ModelAttribute UserProfile inUserProfile) {
		// call service to save user profile
		UserProfile userProfile = userService.saveUserProfile(inUserProfile);
		userProfile = userService.saveUserProfile(userProfile);
		return "redirect:/showProfile";
	}	
	
	@RequestMapping(value = "/updateUserInfo", method = RequestMethod.GET)
	public ModelAndView updateUserInfo(HttpSession session) {
		System.out.println("updateUserInfo userId: " + session.getAttribute("login_id"));
		Optional<User> user = userService.findById((Long) session.getAttribute("login_id"));
		UserProfile userProfile = user.get().getUserProfile();
		System.out.println("updateUserInfo userProfile: " + userProfile);
		if (userProfile == null) 
			userProfile = new UserProfile();
		System.out.println("updateUserInfo userProfile: " + userProfile);
		ModelAndView mav = new ModelAndView("updateUserInfo");
		mav.addObject("userProfile", userProfile);
		return mav;
	}	
	
	@RequestMapping(value = "/updateEducation", method = RequestMethod.GET)
	public ModelAndView updateEducation(HttpSession session) {
		System.out.println("updateUserInfo userId: " + session.getAttribute("login_id"));
		Optional<User> user = userService.findById((Long) session.getAttribute("login_id"));
		UserProfile userProfile = user.get().getUserProfile();
		ModelAndView mav = new ModelAndView("updateEducation");
		mav.addObject("userProfile", userProfile);
		return mav;
	}
	
	@RequestMapping(value = "/addEducation", method = RequestMethod.GET)
	public ModelAndView addEducation(@RequestParam("id") long id) {
		ModelAndView mav = new ModelAndView("addEducation");
		mav.addObject("userProfileId", id);
		return mav;
	}
	
	@RequestMapping(value = "/insertEducation", method = RequestMethod.POST)
	public String insertEducation(@RequestParam("id") long id, @ModelAttribute Education education) {
		userService.saveEducation(education, id);
		return "redirect:/showProfile";
	}
	
	@RequestMapping(value = "/addSkill", method = RequestMethod.GET)
	public ModelAndView addSkill(@RequestParam("id") long id) {
		ModelAndView mav = new ModelAndView("addSkill");
		mav.addObject("userProfileId", id);
		return mav;
	}
	
	@RequestMapping(value = "/insertSkill", method = RequestMethod.POST)
	public String insertSkill(@RequestParam("id") long id, @ModelAttribute Skill skill) {
		userService.saveSkill(skill, id);
		return "redirect:/showProfile";
	}
	
	@RequestMapping(value = "/addExperience", method = RequestMethod.GET)
	public ModelAndView addExperience(@RequestParam("id") long id) {
		ModelAndView mav = new ModelAndView("addExperience");
		mav.addObject("userProfileId", id);
		return mav;
	}
	
	@RequestMapping(value = "/insertExperience", method = RequestMethod.POST)
	public String insertExperience(@RequestParam("id") long id, @ModelAttribute Experience experience) {
		userService.saveExperience(experience, id);
		return "redirect:/showProfile";
	}
	
	@RequestMapping(value = "/showUsers", method = RequestMethod.GET)
	public ModelAndView showUsers() {
		List<User> userList = userService.findAll();
		ModelAndView mav = new ModelAndView("showUsers");
		mav.addObject("userList", userList);
		return mav;
	}
	
}
