/**
 * 
 */
package com.weechong_teo.wdf.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.weechong_teo.wdf.entity.User;
import com.weechong_teo.wdf.repository.UserRepository;

/**
 * @author WeeChong
 *
 */
@Service
@Transactional
public class LoginService {
	
	@Autowired
	UserRepository userRepository;
	
	public User findByUserName (String userName) {
		return userRepository.findByUserName(userName);
	}
	public Optional<User> isValidUser(User loginUser) {
		return userRepository.findByUserNameAndPassword(loginUser.getUserName(), loginUser.getPassword());
	}

}
