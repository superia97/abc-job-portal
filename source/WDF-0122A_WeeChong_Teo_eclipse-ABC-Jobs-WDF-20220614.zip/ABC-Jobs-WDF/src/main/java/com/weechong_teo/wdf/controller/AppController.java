/**
 * 
 */
package com.weechong_teo.wdf.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.weechong_teo.wdf.entity.User;

/**
 * @author WeeChong
 *
 */
@Controller
public class AppController {

	@RequestMapping("/") // Home / Landing page
	public String index() {
		return "home";
	}

	@RequestMapping("/home") // Home / Landing page
	public String home() {
		return "home";
	}	
	

	
	@RequestMapping("/mainPage") // main page
	public String main() {

		return "mainPage";
	}

}
