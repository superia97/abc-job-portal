/**
 * WDF-0122A_WeeChong_Teo
 */
package com.weechong_teo.wdf.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * @author WeeChong
 *
 */
@Entity // Map to DB Table Experience
@Table (name = "Experience")
public class Experience {
	// Field experienceId is annotated with @Id and @GeneratedValue annotations to indicate that 
	// this field is primary key and its value is auto generated.
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long experienceId;
	
	@Column(name="position")
	private String position;
	
	@Column(name="company")
	private String company;
	
	@Column(name="duration")
	private String duration;
	
//	@ManyToOne		// one id belongs to only one userProfile
//	@JoinColumn(name="experienceUserProfileId")
//	private UserProfile experienceUserProfile;
	
	@Column(name="experienceUserProfileId")
	private Long experienceUserProfileId;
	
	public Experience() {
		super();
	}

	public Long getExperienceId() {
		return experienceId;
	}

	public void setExperienceId(Long experienceId) {
		this.experienceId = experienceId;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public Long getExperienceUserProfileId() {
		return experienceUserProfileId;
	}

	public void setExperienceUserProfileId(Long experienceUserProfileId) {
		this.experienceUserProfileId = experienceUserProfileId;
	}



//	public UserProfile getExperienceUserProfile() {
//		return experienceUserProfile;
//	}
//
//	public void setExperienceUserProfile(UserProfile experienceUserProfile) {
//		this.experienceUserProfile = experienceUserProfile;
//	}


}
