/**
 * 
 */
package com.weechong_teo.wdf.auth;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

/**
 * @author WeeChong
 *
 */
public class SpringSecurityInitializer extends AbstractSecurityWebApplicationInitializer {

}
