/**
 * 
 */
package com.weechong_teo.wdf.service;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.weechong_teo.wdf.entity.Education;
import com.weechong_teo.wdf.entity.Experience;
import com.weechong_teo.wdf.entity.Role;
import com.weechong_teo.wdf.entity.Skill;
import com.weechong_teo.wdf.entity.User;
import com.weechong_teo.wdf.entity.UserProfile;
import com.weechong_teo.wdf.exception.DuplicateEmailException;
import com.weechong_teo.wdf.exception.EmailNotFoundException;
import com.weechong_teo.wdf.repository.EducationRepository;
import com.weechong_teo.wdf.repository.ExperienceRepository;
import com.weechong_teo.wdf.repository.RoleRepository;
import com.weechong_teo.wdf.repository.SkillRepository;
import com.weechong_teo.wdf.repository.UserProfileRepository;
import com.weechong_teo.wdf.repository.UserRepository;


/**
 * @author WeeChong
 *
 */
@Service
@Transactional
public class UserService {

	@Autowired
	UserRepository userRepository;
	
	@Autowired
	UserProfileRepository userProfileRepository;
	
	@Autowired
	RoleRepository roleRepository;
	
	@Autowired
	EducationRepository educationRepository;
	
	@Autowired
	SkillRepository skillRepository;
	
	@Autowired
	ExperienceRepository experienceRepository;
	
	// Register
	public UserProfile register(UserProfile userProfile) throws DuplicateEmailException {
		if (userProfileRepository.findByEmail(userProfile.getEmail()) != null ) {
			throw new DuplicateEmailException(userProfile.getEmail() + " already exists!");
		} else {
			Optional<Role> role = roleRepository.findByName("Member");
			userProfile.setRole(role.get());
			
			userProfile = userProfileRepository.saveAndFlush(userProfile);
			
			User user = new User();
			user.setUserName(userProfile.getEmail());
			user.setPassword(userProfile.getPassword());
			user.setUserProfile(userProfile);
			userRepository.saveAndFlush(user);
			
			return userProfile;
		}
	}
	
	// Get User
	public Optional<User> findById(Long id) {
		return userRepository.findById(id);
	}
	
	// Get All Users
	public List<User> findAll() {
		return userRepository.findAll();
	}
	
	// Reset Password
	public void resetPassword(User user) throws EmailNotFoundException {
		if (userRepository.findByUserName(user.getUserName()) == null) {
			throw new EmailNotFoundException(user.getUserName() + " not found.");
		} else {
			user = userRepository.findByUserName(user.getUserName());
			long now = System.currentTimeMillis();
	        Timestamp sqlTimestamp = new Timestamp(now);
			// TODO create reset link and email
			user.setReset("reset");
			userRepository.saveAndFlush(user);
		}
	}
	
	public UserProfile saveUserProfile(UserProfile userProfile) {
		UserProfile current = userProfileRepository.findById(userProfile.getUserProfileId()).get();
		
		current.setFirstName(userProfile.getFirstName());
		current.setLastName(userProfile.getLastName());
		current.setDateOfBirth(userProfile.getDateOfBirth());
		current.setGender(userProfile.getGender());
		current.setCity(userProfile.getCity());
		current.setCountry(userProfile.getCountry());
		
		return userProfileRepository.saveAndFlush(current);
		
	}

	public Education saveEducation(Education education, long id) {
//		education.setUserProfile(userProfileRepository.findById(id).get());
		education.setUserProfileId(id);
		return educationRepository.saveAndFlush(education);
	}

	public List<Education> findAllEducation(Long userProfileId) {
		return educationRepository.findAllByUserProfileId(userProfileId);
	}

	public Skill saveSkill(Skill skill, long id) {
		// Get user profile using id
		UserProfile userProfile = userProfileRepository.findById(id).get();
		skill.setSkillUserProfile(userProfile);
		return skillRepository.saveAndFlush(skill);
		
	}

//	public Experience saveExperience(Experience experience, long id) {
//		// Get user profile using id
//		UserProfile userProfile = userProfileRepository.findById(id).get();
//		experience.setExperienceUserProfile(userProfile);
//		return experienceRepository.saveAndFlush(experience);
//	}

	public List<Experience> findAllExperience(Long userProfileId) {
		return experienceRepository.findAllByUserProfileId(userProfileId);
	}

	public Experience saveExperience(Experience experience, long id) {
		experience.setExperienceUserProfileId(id);
		return experienceRepository.saveAndFlush(experience);
	}

	public List<UserProfile> search(String searchText) {
//		return userProfileRepository.findAll();
		return userProfileRepository.search(searchText);
	}

//	public List<Skill> findAllSkill(Long userProfileId) {
//		return skillRepository.findAllBySkillUserProfileId(userProfileId);
//	}
	
//	public List<Education> findAllEducations(long userProfileId) {
//		return educationRepository.findAllByUserProfileId(userProfileId);
//	}
	
	
}
