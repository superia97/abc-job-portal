/**
 * 
 */
package com.weechong_teo.wdf.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.weechong_teo.wdf.entity.Education;
import com.weechong_teo.wdf.entity.Experience;

/**
 * @author WeeChong
 *
 */
public interface ExperienceRepository extends JpaRepository<Experience, Long> {

	@Query( "select r from Experience r where r.experienceUserProfileId = :userProfileId" )
	List<Experience> findAllByUserProfileId(@Param("userProfileId") long userProfileId);

}
