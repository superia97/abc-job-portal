/**
 * 
 */
package com.weechong_teo.wdf.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.weechong_teo.wdf.entity.Education;

/**
 * @author WeeChong
 *
 */
public interface EducationRepository extends JpaRepository<Education, Long> {

	@Query( "select r from Education r where r.userProfileId = :userProfileId" )
	List<Education> findAllByUserProfileId(@Param("userProfileId") long userProfileId);

}
