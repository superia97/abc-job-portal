/**
 * 
 */
package com.weechong_teo.wdf.controller;

import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.weechong_teo.wdf.entity.User;
import com.weechong_teo.wdf.service.LoginService;
import com.weechong_teo.wdf.service.UserService;

/**
 * @author WeeChong
 *
 */
@Controller
public class LoginController {
	@Autowired
	LoginService loginService;
	
	@Autowired
	UserService userService;

	@RequestMapping(value = "/showLogin", method = RequestMethod.GET)
	public ModelAndView showLogin() {
		ModelAndView mav = new ModelAndView("login");
		mav.addObject("login", new User());
		return mav;
	}
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView onLogin(@ModelAttribute User inputUser, HttpSession session) {
		ModelAndView mav = null;

		Optional<User> loginUser = loginService.isValidUser(inputUser);
		
		if (loginUser == null || !loginUser.isPresent()) {
			mav = new ModelAndView("login");
			mav.addObject("errMsg", "Oops! Your email or password is incorrect!");
		} else {
			Optional<User> user = userService.findById(loginUser.get().getUserId());
			mav = new ModelAndView("mainPage");
			mav.addObject("loginUser", user.get());
			session.setAttribute("login_email", user.get().getUserName());
			session.setAttribute("login_id", user.get().getUserId());
			session.setAttribute("login_role", user.get().getUserProfile().getRole().getName());
			if (user.get().getUserProfile().getRole().getName().compareTo("Administrator")==0) {
				session.setAttribute("isAdmin", "1");
			} else {
				session.setAttribute("isAdmin", "0");
			}
		}

		return mav;
	}
	
	@RequestMapping(value = "/login-error", method = RequestMethod.GET)
	@ExceptionHandler(Exception.class)
	public ModelAndView onLoginError(@ModelAttribute("login") User login, Exception ex) {
		System.out.println("/login-error:");
		System.out.println(ex.getMessage());
//		ex.printStackTrace();
		ModelAndView mav = null;
		mav = new ModelAndView("login");
		mav.addObject("errMsg", ex.getMessage());
		return mav;
	}
}
