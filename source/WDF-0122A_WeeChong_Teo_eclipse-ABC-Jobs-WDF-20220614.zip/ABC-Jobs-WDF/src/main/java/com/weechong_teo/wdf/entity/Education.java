/**
 * WDF-0122A_WeeChong_Teo
 */
package com.weechong_teo.wdf.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

/**
 * @author WeeChong
 *
 */
@Entity // Map to DB Table Education
public class Education {
	// Field educationId is annotated with @Id and @GeneratedValue annotations to indicate that 
	// this field is primary key and its value is auto generated.
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long educationId;
	private String description;
	private String institute;
	private String year;
	private Long userProfileId; 
	
//	@ManyToOne
//	@JoinColumn(name = "userProfileId")
//	private UserProfile userProfile;
	
	public Education() {
		super();
	}

	public Long getEducationId() {
		return educationId;
	}

	public void setEducationId(Long educationId) {
		this.educationId = educationId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getInstitute() {
		return institute;
	}

	public void setInstitute(String institute) {
		this.institute = institute;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public Long getUserProfileId() {
		return userProfileId;
	}

	public void setUserProfileId(Long userProfileId) {
		this.userProfileId = userProfileId;
	}

//	public UserProfile getUserProfile() {
//		return userProfile;
//	}
//
//	public void setUserProfile(UserProfile userProfile) {
//		this.userProfile = userProfile;
//	}


}
