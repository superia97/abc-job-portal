/**
 * WDF-0122A_WeeChong_Teo
 */
package com.weechong_teo.wdf.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * @author WeeChong
 *
 */
@Entity // Map to DB Table Skill
@Table (name = "Skill")
public class Skill {
	// Field skillId is annotated with @Id and @GeneratedValue annotations to indicate that 
	// this field is primary key and its value is auto generated.
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long skillId;
	
	@Column(name="description")
	private String description;
	
	@Column(name="institute")
	private String institute;
	
	@Column(name="year")
	private String year;
	
	@ManyToOne		// one id belongs to only one userProfile
	@JoinColumn(name="skillUserProfileId")
	private UserProfile skillUserProfile;
	
//	private Long userProfileId;
	
	public Skill() {
		super();
	}

//	public Skill(String description, String institute, String year, Long userProfileId) {
//		super();
//		this.description = description;
//		this.institute = institute;
//		this.year = year;
//		this.userProfileId = userProfileId;
//	}

	public Long getSkillId() {
		return skillId;
	}

	public void setSkillId(Long skillId) {
		this.skillId = skillId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getInstitute() {
		return institute;
	}

	public void setInstitute(String institute) {
		this.institute = institute;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public UserProfile getSkillUserProfile() {
		return skillUserProfile;
	}

	public void setSkillUserProfile(UserProfile skillUserProfile) {
		this.skillUserProfile = skillUserProfile;
	}

//	public Long getUserProfileId() {
//		return userProfileId;
//	}
//
//	public void setUserProfileId(Long userProfileId) {
//		this.userProfileId = userProfileId;
//	}
	
}
