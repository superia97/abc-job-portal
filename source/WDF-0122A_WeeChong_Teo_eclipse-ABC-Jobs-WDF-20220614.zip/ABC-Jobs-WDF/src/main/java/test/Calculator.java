package test;

public class Calculator {
    private int firstOperand;
    private int secondOperand;

    public Calculator (int operand1, int operand2){
        this.firstOperand = operand1;
        this.secondOperand = operand2;
    }
    /*
    public Calculator (int operand){
        this.firstOperand = operand;
        this.secondOperand = operand;
    }*/

    public Calculator (int operand){

        this(operand,operand);
    }


    public  Calculator (){
        this(1, 1);
    }

    public int getFirstOperand() {
        return firstOperand;
    }


    public void setFirstOperand(int firstOperand) {
        this.firstOperand = firstOperand;
    }

    public int getSecondOperand() {
        return secondOperand;
    }

    public void setSecondOperand(int secondOperand) {
        this.secondOperand = secondOperand;
    }


    public int add(){
        return this.firstOperand + this.secondOperand;
    }

    public int substract(){
        return  this.firstOperand - this.secondOperand;
    }

    public int multiply(){
        return this.firstOperand * this.secondOperand;
    }

//    public int divide() throws DivisionByZeroException {
//        try {
//            return this.firstOperand / this.secondOperand;
//        }catch (ArithmeticException e)
//        {
//            throw new DivisionByZeroException(e.getMessage());
//        }
//    }
}

