-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: localhost    Database: cpj_0122a
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `education`
--

DROP TABLE IF EXISTS `education`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `education` (
  `educationId` int NOT NULL AUTO_INCREMENT COMMENT 'Unique ID for education',
  `description` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'Description of education',
  `year` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'Year of achievement',
  `institute` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT 'Institute where education was achieved',
  `userProfileId` int NOT NULL COMMENT 'FK to userprofile table',
  PRIMARY KEY (`educationId`),
  KEY `userProfileId` (`userProfileId`),
  CONSTRAINT `education_ibfk_1` FOREIGN KEY (`userProfileId`) REFERENCES `userprofile` (`userProfileId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `education`
--

LOCK TABLES `education` WRITE;
/*!40000 ALTER TABLE `education` DISABLE KEYS */;
INSERT INTO `education` VALUES (105,'Master of Science','2000','NUS',124),(114,'Master in BA','1999','NUS',145),(115,'Master of Science','1999','NTU',146),(118,'Master of Science','2000','Seoul University',152);
/*!40000 ALTER TABLE `education` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `experience`
--

DROP TABLE IF EXISTS `experience`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `experience` (
  `experienceId` int NOT NULL AUTO_INCREMENT COMMENT 'Unique ID for experience',
  `company` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT 'Company of employment',
  `position` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT 'Position held',
  `duration` varchar(128) NOT NULL COMMENT 'Duration of position held',
  `experienceUserProfileId` int NOT NULL COMMENT 'FK to userprofile table',
  PRIMARY KEY (`experienceId`),
  KEY `userProfileId` (`experienceUserProfileId`),
  KEY `ixCompany` (`company`),
  CONSTRAINT `experience_ibfk_1` FOREIGN KEY (`experienceUserProfileId`) REFERENCES `userprofile` (`userProfileId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `experience`
--

LOCK TABLES `experience` WRITE;
/*!40000 ALTER TABLE `experience` DISABLE KEYS */;
INSERT INTO `experience` VALUES (108,'ABC Jobs Pte Ltd','Administrator','2000-Present',124),(109,'Meta','Software Development Manager','1999-Present',145),(111,'Amazon','Full Stack Developer','2000-Present',146),(112,'Adecco Personnel Pte Ltd','Software Developer','1999-2000',146),(116,'Adecco Personnel Pte Ltd','Java Developer','2000-Present',152);
/*!40000 ALTER TABLE `experience` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job`
--

DROP TABLE IF EXISTS `job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job` (
  `jobId` int NOT NULL AUTO_INCREMENT COMMENT 'Unique ID for job',
  `description` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'Description of job',
  `position` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'Job position or title',
  `type` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'Job type',
  `jobReferenceNo` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'Job reference number',
  `company` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'Hiring company',
  `location` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'Location of employment',
  `closingDate` varchar(20) NOT NULL COMMENT 'Closing date for job application',
  `salary` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT 'Salary offered',
  `userId` int NOT NULL COMMENT 'User ID of creator. FK to user table',
  PRIMARY KEY (`jobId`),
  KEY `userId` (`userId`),
  CONSTRAINT `job_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job`
--

LOCK TABLES `job` WRITE;
/*!40000 ALTER TABLE `job` DISABLE KEYS */;
INSERT INTO `job` VALUES (55,'As a Software Engineer in D-SIMLAB, you will get exposure in both technical and soft skills development. The role does not limit to only software development, but also involves in providing professional consultation services to customers, with the following key responsibilities:\r\n\r\nWork together with a team of highly skilled Software Engineers and Data Scientists in software product deployment and delivery at world leading semiconductor manufacturers.\r\nActively involved in product enhancement (in the area of visualization and algorithms) which improves the quality of D-SIMLAB product.\r\nResponsible for key software components development.\r\n\r\nWe are looking for candidates fulfil the following criteria:\r\n\r\nBachelor/Master Degree specialises in Computer Science/Engineering or Industrial Engineering.\r\nDiploma holders with relevant experience are encouraged to apply.\r\nEnjoy working with experts with different cultural and technical backgrounds.\r\nLove to travel the world and work on challenging projects.\r\nInterest in career progression by strengthening your technical and soft skills.','Senior Software Engineer ','Permanent','MCF-2022-0483099','Meta','Singapore','10-10-2022','$8,000 to $10,000',183),(56,'Qualifications\r\n\r\nB.S. or M.S. degree in Computer Science or any related technical field.\r\nAt least 3 years of solution development experience.\r\nAt least 5 years of software development with solid experience in MS Access, C, C++, VB Net, SQL.\r\nWith initiative in software development process automation.\r\nStrong sense of responsibility and commitment and be able to handle a team.\r\nKnowledge of Japanese language is an advantage.\r\nResponsibilities and Duties\r\n\r\nReview current systems architecture, coding methodology and language platforms.\r\nPresent ideas for system improvements and provide reasonable technical solutions to specific scenarios and accomplish them across departments.\r\nWork closely with Japan HQ Development team to understand areas that may require improvement, fixes and upgrades.\r\nMaintain the systems and fix software bugs, implement new functionalities and test all systems before releasing to operations.','Software Developer','Permanent','MCF-2022-0215090','Meta','Singapore','18-08-2022','$3,500 to $5,000',183),(57,'Responsibilities\r\n\r\nTranslate requirements and user wish lists into development components design documents in line with products and solution roadmaps\r\nTranslate design documents into actual code and solution developments that have good functionality and of high quality\r\nRespond to changes in initial requirements and work in an agile manner to deliver iterative features\r\nEnsure that codes developed are tested, maintained and documented\r\nRequirements :\r\n\r\nBachelors or Master in Engineering (Computer/Telecommunication), Computer Science / Information Technology or equivalent\r\nProven experience as a Full Stack Developer or similar role\r\nStrong proficiency with JavaScript\r\nIn depth knowledge of Node.js\r\nFamiliarity with microservices , serverless architectures\r\nKnowledge of multiple back-end languages (e.g. C#, Java, Python) and JavaScript frameworks (e.g. Angular, React)\r\nProficient understanding of code versioning tools, such as Git\r\nStrong knowledge and experience in AWS cloud development, including but not limited to Lambda, API Gateway, IoT, Cognito, DynamoDB\r\nKnowledge of Linux, shell scripting\r\nFamiliarity with relational and non-relational database technologies like MySQL, MongoDB, etc.\r\nExcellent communication and teamwork skills\r\nGreat attention to detail\r\nOrganizational skills\r\nAn analytical mind','Cloud Software Developer','Permanent','MCF-2021-0674174','Google','Singapore','10-10-2022','$7,500 to $9,000',183),(60,'Web','Junior Web Developer','Contract','MCF-2022-0375280','Adecco Personnel Pte Ltd','Singapore','12-10-2022','$5000',190);
/*!40000 ALTER TABLE `job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobapplication`
--

DROP TABLE IF EXISTS `jobapplication`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobapplication` (
  `applicationId` int NOT NULL AUTO_INCREMENT COMMENT 'Unique ID for job application',
  `applicationDate` datetime NOT NULL COMMENT 'Date of application',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'Status of application',
  `expectedSalary` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'Expected salary of applicant',
  `jobId` int NOT NULL COMMENT 'Job ID of application',
  `userId` int NOT NULL COMMENT 'User ID of applicant. FK to user table',
  PRIMARY KEY (`applicationId`),
  KEY `jobId` (`jobId`),
  KEY `userId` (`userId`),
  CONSTRAINT `jobapplication_ibfk_1` FOREIGN KEY (`jobId`) REFERENCES `job` (`jobId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `jobapplication_ibfk_2` FOREIGN KEY (`userId`) REFERENCES `user` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobapplication`
--

LOCK TABLES `jobapplication` WRITE;
/*!40000 ALTER TABLE `jobapplication` DISABLE KEYS */;
INSERT INTO `jobapplication` VALUES (79,'2022-07-13 05:02:01','0','5500',55,190);
/*!40000 ALTER TABLE `jobapplication` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message`
--

DROP TABLE IF EXISTS `message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `message` (
  `messageId` int NOT NULL AUTO_INCREMENT COMMENT 'Unique ID for message',
  `dateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Time stamp of message',
  `receiverUserId` int NOT NULL COMMENT 'User ID of receiver. FK to user table',
  `content` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'Message content',
  `replyToMsgId` int DEFAULT NULL COMMENT 'Message ID to reply',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '0' COMMENT 'Status of message',
  `userId` int NOT NULL COMMENT 'User ID of sender. FK to user table',
  PRIMARY KEY (`messageId`),
  KEY `userId` (`userId`),
  KEY `receiverUserId` (`receiverUserId`),
  CONSTRAINT `message_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `receiverUserId` FOREIGN KEY (`receiverUserId`) REFERENCES `user` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1047 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message`
--

LOCK TABLES `message` WRITE;
/*!40000 ALTER TABLE `message` DISABLE KEYS */;
INSERT INTO `message` VALUES (1045,'2022-07-13 05:02:52',183,'hello',NULL,'0',190),(1046,'2022-07-13 05:03:01',190,'ok',NULL,'0',183);
/*!40000 ALTER TABLE `message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role` (
  `roleId` int NOT NULL AUTO_INCREMENT COMMENT 'Unique ID for role',
  `name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'Description of role',
  PRIMARY KEY (`roleId`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'Administrator'),(2,'Member');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `skill`
--

DROP TABLE IF EXISTS `skill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `skill` (
  `skillId` int NOT NULL AUTO_INCREMENT COMMENT 'Unique ID of skill',
  `description` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'Description of skill',
  `year` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'Year of achievement',
  `institute` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT 'Institute where skill was achieved	',
  `skillUserProfileId` int NOT NULL COMMENT 'FK to userprofile table',
  PRIMARY KEY (`skillId`),
  KEY `userProfileId` (`skillUserProfileId`),
  CONSTRAINT `skill_ibfk_1` FOREIGN KEY (`skillUserProfileId`) REFERENCES `userprofile` (`userProfileId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `skill`
--

LOCK TABLES `skill` WRITE;
/*!40000 ALTER TABLE `skill` DISABLE KEYS */;
INSERT INTO `skill` VALUES (108,'Server Administration Certification','2021','Lithan',124),(109,'Google Cloud Certified','2000','Google',145),(110,'Google Cloud Certified','2020','Google',146),(113,'Google Cloud Certified','2020','Google',152);
/*!40000 ALTER TABLE `skill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `thread`
--

DROP TABLE IF EXISTS `thread`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `thread` (
  `threadId` int NOT NULL AUTO_INCREMENT,
  `dateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `content` varchar(2048) NOT NULL,
  `replyToThreadId` int DEFAULT NULL,
  `status` char(1) NOT NULL,
  `media` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `userId` int NOT NULL,
  PRIMARY KEY (`threadId`),
  KEY `userId` (`userId`),
  CONSTRAINT `thread_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1042 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `thread`
--

LOCK TABLES `thread` WRITE;
/*!40000 ALTER TABLE `thread` DISABLE KEYS */;
INSERT INTO `thread` VALUES (1034,'2022-07-08 05:06:08','Got hit with this 500 error. Need some guidance to trouble shoot. Thanks.',NULL,'0','http-500-error.png',184),(1040,'2022-07-13 05:02:16','multipart',1034,'0','multipart.png',190),(1041,'2022-07-13 05:04:53','help',NULL,'0','http-403.png',190);
/*!40000 ALTER TABLE `thread` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `userId` int NOT NULL AUTO_INCREMENT COMMENT 'Unique ID for user',
  `email` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'Email of user',
  `password` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'Password for login',
  `emailConfirmed` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '0' COMMENT 'Status to indicate user has confirmed his/her email',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '1' COMMENT 'Status of user account',
  `createdDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Date of account creation',
  `reset` varchar(256) DEFAULT NULL,
  `userProfileId` int DEFAULT NULL,
  PRIMARY KEY (`userId`),
  UNIQUE KEY `email` (`email`),
  KEY `userProfileId_idx` (`userProfileId`),
  CONSTRAINT `userProfile_fk` FOREIGN KEY (`userProfileId`) REFERENCES `userprofile` (`userProfileId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=191 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (163,'admin@abc.com','1212','0','0','2022-06-09 14:04:58','',124),(183,'monica@gmail.com','1212','0','0','2022-07-07 03:13:06',NULL,145),(184,'ken@gmail.com','1212','0','0','2022-07-07 03:17:26',NULL,146),(190,'chawu97@gmail.com','1212','0','0','2022-07-13 05:00:07',NULL,152);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userprofile`
--

DROP TABLE IF EXISTS `userprofile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userprofile` (
  `userProfileId` int NOT NULL AUTO_INCREMENT COMMENT 'Unique ID for user profile',
  `gender` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT 'Gender of user',
  `dateOfBirth` varchar(20) DEFAULT NULL COMMENT 'Date of birth of user',
  `city` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT 'City where user is located',
  `country` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT 'Country where user is located',
  `firstName` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT 'First name of user',
  `lastName` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT 'Last name of user',
  `photo` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT 'Photo of user',
  `email` varchar(128) NOT NULL,
  `roleId` int DEFAULT NULL,
  PRIMARY KEY (`userProfileId`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  KEY `ixFirstName` (`firstName`),
  KEY `ixLastName` (`lastName`),
  KEY `ixCity` (`city`),
  KEY `ixCountry` (`country`),
  KEY `roleId_fk_idx` (`roleId`),
  CONSTRAINT `roleId_fk` FOREIGN KEY (`roleId`) REFERENCES `role` (`roleId`)
) ENGINE=InnoDB AUTO_INCREMENT=153 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userprofile`
--

LOCK TABLES `userprofile` WRITE;
/*!40000 ALTER TABLE `userprofile` DISABLE KEYS */;
INSERT INTO `userprofile` VALUES (124,'Male','12-12-1980','Singapore','Singapore','Austin','Pow','austin.jpg','admin@abc.com',1),(145,'Female','01-01-1980','Singapore','Singapore','Monica','Kool','monica.jpg','monica@gmail.com',2),(146,'Male','11-11-1978','Singapore','Singapore','Ken','Gold','ken.jpg','ken@gmail.com',2),(152,'Male','01-01-1980','Seoul','South Korea','Cha','Wu','chawu.png','chawu97@gmail.com',2);
/*!40000 ALTER TABLE `userprofile` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-13 13:10:06
